# DanielSteginkUtils

A code library containing various helper classes and logic I've accumulated in my modding journey.

General structure:
- Utilities - Various libraries for logic and calculations
	- ClassIntegrations - Accesses properties, fields and methods from other classes